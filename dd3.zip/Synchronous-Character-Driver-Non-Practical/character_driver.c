#include <linux/init.h>
#include <linux/module.h> /** needed by all modules **/
#include <linux/kernel.h>  /** This is for KERN_ALERT **/
#include <linux/fs.h> /** for file operations **/
#include <linux/cdev.h>  /** character device **/
#include <linux/device.h>  /** for sys device registration in /dev/ and /sys/class **/
/** for copy_to_user **/
#include <asm/uaccess.h>


/** For class registration to work, you need GPL license **/
MODULE_LICENSE("GPL");


static struct cdev basicCdev;
static struct class *basicDriverClass;
static int  basicMajorNumber = 0;

#define NUMBER_OF_MINOR_DEVICE (0)

/** Prototype for read, this will be invoked when the read function is done on to the driver **/
/** The declaration type is file operations based function pointer - read **/
static ssize_t basicRead(struct file *filp, char *buffer, size_t length,loff_t *offset);
static int basicOspen(struct inode *inode, struct file *file);

/** File Operations function pointer table **/
/** There are plenty of file operations  **/

static struct file_operations fops =
{
    .read = basicRead,
    .write = NULL,
    .open = basicOspen,
    .release = NULL
};

static ssize_t basicRead(struct file *filp, char *buffer, size_t length, loff_t *offset)
{
    char msg[1024] = "Hello SJ_read\0";
    printk(KERN_ALERT "The Read operation called\r\n");
    copy_to_user( buffer, msg, sizeof(msg) );
    return sizeof(msg);
}

static int basicOspen(struct inode *inode, struct file *file)
{

    printk("Kernel.Basic Driver Opened now!!\r\n");

    return 0;
}

static void setup_cdev(struct cdev *dev, int minor, struct file_operations *fops)
{
    int err = -1;
    /** MKDEV call creates a device number i.e. combination of major and minor number **/
    int devno = MKDEV(basicMajorNumber, minor);
    /** Initiliaze character dev with fops **/
    cdev_init(dev, fops);
    /**owner and operations initialized **/
    dev->owner = THIS_MODULE;
    dev->ops = fops;
    /** add the character device to the system**/
    /** Here 1 means only 1 minor number, you can give 2 for 2 minor device, the last param is the count of minor number enrolled **/
    err = cdev_add (dev, devno, minor);

    if (err)
    {
        printk (KERN_NOTICE "Couldn't add cdev");
    }
}

static int chrDriverInit(void)
{

    int result;
    dev_t dev;
    dev_t dev2;

    printk("Welcome!! Device Init now..");

    /** int alloc_chrdev_region(dev_t *dev, unsigned int firstminor,unsigned int count, char *name);  **/
    /** dev -> The dev_t variable type,which will get the major number that the kernel allocates.  **/
    /**The same name will appear in /proc/devices.  **/

    /** it is registering the character device **/
    /** a major number will be dynamically allocated here **/
    /**  alloc_chrdev_region(&dev_num, FIRST_MINOR, COUNT, DEVICE_NAME); **/
    result = alloc_chrdev_region(&dev, 0, NUMBER_OF_MINOR_DEVICE, "pSeudoDrv");

    if( result < 0 )
    {
        printk("Error in allocating device");
        return -1;
    }

    /** Now setup the cdev **/
    setup_cdev(&basicCdev,NUMBER_OF_MINOR_DEVICE, &fops);

    /** From these two if's we are avoiding the manual mknod command to create the /dev/<driver> **/
    /**  creating class, and then device created removes the dependency of calling mknod  **/
    /** A good method - the mknod way is depreciated **/
    /** mknod way is -  mknod /dev/<driver_name> c <majorNumber> <minorNumber>


        /** add the driver to /sys/class/chardrv **/
    if ((basicDriverClass = class_create(THIS_MODULE, "chardrv")) == NULL)    //$ls /sys/class
    {
        unregister_chrdev_region(dev, 1);
        return -1;
    }

#if 1
    /** add the driver to /dev/pSeudoDrv -- here **/
    if (device_create(basicDriverClass, NULL, dev, NULL, "pSeudoChrDrv") == NULL) //$ls /dev/
    {
        class_destroy(basicDriverClass);
        unregister_chrdev_region(dev, 1);
        return -1;
    }
#endif
    /** let's see what major number was assigned by the Kernel **/
    basicMajorNumber = MAJOR(dev);
    printk("Kernel assigned major number is %d ..\r\n",basicMajorNumber );

    return 0;

}


static void chrDriverExit(void)
{
    /** A reverse - destroy mechansim -- the way it was created **/
    printk("Releasing Simple Devs -- %s\r\n",  __FUNCTION__);
    /** delete the character driver added **/
    cdev_del(&basicCdev);
    /** destroy the device created **/
    device_destroy(basicDriverClass, MKDEV(basicMajorNumber, 0));
    /** destroy the class created **/
    class_destroy(basicDriverClass);
    /** unregister the chr dev **/
    unregister_chrdev(basicMajorNumber, NUMBER_OF_MINOR_DEVICE);

}


module_init(chrDriverInit);
module_exit(chrDriverExit);

